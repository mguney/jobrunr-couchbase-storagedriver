package app.model;

public record StateCountsOnly(String state, Long count) {
    
}
