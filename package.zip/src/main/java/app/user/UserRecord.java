package app.user;

public record UserRecord(String firstName, Long count) {

}
