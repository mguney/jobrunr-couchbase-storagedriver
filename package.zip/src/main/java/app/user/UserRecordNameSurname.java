package app.user;

public record UserRecordNameSurname(String firstName, String lastName) {

}
