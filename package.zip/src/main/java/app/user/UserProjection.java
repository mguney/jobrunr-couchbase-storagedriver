package app.user;

public interface UserProjection {

    String getFirstName();
    String getLastName();
}
